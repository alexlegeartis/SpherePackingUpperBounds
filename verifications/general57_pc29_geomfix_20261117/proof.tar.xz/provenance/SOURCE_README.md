#57D unrestricted sphere-packing upper-bound candidate

Degree29 two-profile compact cyclic kernel, R=19/13, powers12/24; degree71 Fourier polynomial. No lattice, antipodal, integrality or mod2 assumptions.

Exact PSD/angular/12edge/Fourier/tail/annular/cap certificates pass. Scalar safe upper1.5718326e-8 is conditional on completion of the full3D cyclic gate and independent audit. Do not publish as an unconditional bound yet.
