# Independent audit of fresh 51D general upper-bound candidate

Status: PASS. All seven audit stages completed successfully. The verified unrestricted sphere-packing density upper bound is 1.39812853e-7 in dimension 51. Complete geometry replay: 98,507 nodes, 49,254 accepted leaves, at 512-bit precision; maximum certified leaf upper bound is below -1.6042848e-6. All 633 radial annuli were regenerated, and all frozen critical inputs stayed byte-identical. See AUDIT_COMPLETE.json, main_independent_result.json and audit_0.log through audit_6.log.

The source is general51_pc29_geomfix_20261117, not the rejected earlier pc29_repair package. Frozen inputs are recorded in AUDIT_INPUT_HASHES.json. No lattice, antipodal, integrality, or mod-2 premise is used.

## Checks

- A separate trace replayer rebuilds the dimension-51 normalized Gegenbauer polynomials from exact frozen matrix coefficients using SymPy. It checks every accepted leaf at 512-bit Arb precision, using natural interval, first-order and second-order Taylor bounds. Split instructions recursively partition the exact unit cube; an empty terminal stack and nodes=2*leaves-1 prove exhaustive coverage. Each accepted leaf satisfies the strict -1e-7 threshold.
- The sorted-side cube parametrization is a=1+(6/13)x, b=a+(6/13)(1-x)y, c=b+(6/13)(1-x)(1-y)z. Since sqrt(19/13)<2 every point represents a triangle. The cyclic expression divided by h(a)h(b) has a continuous extension to the closed cube using ratios (1-z)^12 and ((1-y)(1-z))^12. Thus no zero-support boundary was dropped.
- Outside the cube, if at least two sides exceed support every term vanishes; with one side outside, the surviving cosine lies in [-1,1/2]. All three distinct bilinear corners are checked over that full interval, including negative angles, by exact polynomial critical-point isolation. Independent edge interval reruns are additional checks, not substitutes for full coverage.
- Exact rational harmonic block PSD and origin Schur complement are checked separately. The scalar kernel must be byte-identical to the geometrically certified kernel.
- The degree-71 radial Gaussian Fourier transform is checked using exact Laguerre coefficients, factor positivity, complete polynomial root coverage and the infinite negative spatial tail. The n/2 parameter in this transform is exact and dimension-dependent.
- The full radial annulus certificate is regenerated. Contiguous annuli cover from the contact coordinate d through 180; widths are at most d, justifying the outer-radius spherical-code angle. Every positive residual height uses an exact verified Gegenbauer code polynomial, not an unchecked analytic fallback. Cap summation and scalar/kernel identities are checked.
- Density is reconstructed independently from (d/4)^(n/2)/Gamma(n/2+1) times P(0)+s+budget. Even-dimensional normalization is exact rational. The safe decimal is checked as the exact ceiling at 1e-15 resolution. Generic odd-dimensional audits additionally use an independent Machin lower enclosure for pi and 2048-bit Arb gamma normalization.

## Scope and reproducibility

The full geometry replayer and normalization/binding checker are separate audit programs. The reviewed source Fourier, cap and radial interval algorithms are rerun on the frozen copy; this is not a claim of two wholly independent implementations of every arithmetic algorithm. Arithmetic ultimately trusts python-flint/Arb and Python/SymPy rational operations.

See audit_0.log through audit_6.log in order: complete trace, corners, edges, Fourier/tail, annuli, caps, exact bindings/normalization. Run with assertions enabled and PYTHONPATH pointing to an installation of python-flint. The coordinator script records its exact command sequence and runs one CPU6 process at a time.
