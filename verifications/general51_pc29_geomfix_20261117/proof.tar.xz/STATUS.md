PRODUCER COMPLETE: unrestricted51D upper1.39812853e-07. Full3D cyclic coverage98507nodes/49254leaves. Independent audit pending.
