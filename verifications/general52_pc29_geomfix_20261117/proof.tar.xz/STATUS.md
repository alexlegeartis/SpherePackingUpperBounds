PASS: complete independently replayed unrestricted 52D certificate. See AUDIT.md and README.md.
