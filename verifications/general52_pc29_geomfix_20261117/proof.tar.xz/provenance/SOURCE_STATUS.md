PENDING FULL3D CYCLIC PROOF AND INDEPENDENT AUDIT. Other components pass, including complete12edge interval proofs.
