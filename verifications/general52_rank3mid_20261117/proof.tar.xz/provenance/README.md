Original audit manifest and checksums retained. The original MANIFEST.json entry refers to SOURCE_MANIFEST.json here; remaining files are unchanged at package root.
