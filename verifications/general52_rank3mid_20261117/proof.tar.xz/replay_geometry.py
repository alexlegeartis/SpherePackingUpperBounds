import sys,math,json,time,hashlib
from pathlib import Path
from fractions import Fraction as F
import sympy as s
from flint import arb,ctx
from jet import Jet,pe2
if not __debug__:raise RuntimeError('Do not use -O')
sys.set_int_max_str_digits(0);ctx.prec=512;n=int(sys.argv[1]);D=Path(__file__).parent/'geometry'/f'dim{n}';mode='main';z=json.load(open(D/'frozen.json'));assert z['dimension']==n and z['R']=='19/13' and z['powers']==[12,18,24];co=list(map(s.Rational,z['co']));Bs=[[[s.Rational(x)for x in row]for row in B]for B in z['B']];x=s.symbols('x');pol=[]
indices=[(i,j) for i in range(3) for j in range(3)]
for i,j in indices:
 P=s.Poly(sum(co[k]*Bs[k][i][j]*s.gegenbauer(k,s.Rational(n-2,2),x)/s.gegenbauer(k,s.Rational(n-2,2),1)for k in range(len(co))),x);pol.append([arb(int(P.nth(k).p))/int(P.nth(k).q)for k in range(len(co))])
assert len(Bs)==len(co)==30 and co[0]==1 and min(co)>0
import itertools
for B in Bs:
 M=s.Matrix(B);assert M==M.T and M.shape==(3,3)
 for size in (1,2,3):
  for ix in itertools.combinations(range(3),size):assert M.extract(ix,ix).det()>=0
def ar(v):v=F(v);return arb(v.numerator)/v.denominator
def bil(t,u,v):
 U=[1,u,u*u];V=[1,v,v*v]
 return sum((pe2(pol[k],t)*U[i]*V[j] for k,(i,j) in enumerate(indices)),Jet(0))
def parts(x,y,z):
 e=ar(F(6,13));a=1+e*x;b=a+e*(1-x)*y;c=b+e*(1-x)*(1-y)*z
 A=(1-x)**6;B=A*(1-y)**6;C=B*(1-z)**6
 return bil((a+b-c)/(2*(a*b).sqrt()),A,B)+(1-z)**12*bil((a+c-b)/(2*(a*c).sqrt()),A,C)+((1-y)*(1-z))**12*bil((b+c-a)/(2*(b*c).sqrt()),B,C)
def check(box):
 mids=[(box[2*i]+box[2*i+1])/2 for i in range(3)];rads=[(box[2*i+1]-box[2*i])/2 for i in range(3)];args=[Jet(arb(ar(m),ar(r)),[arb(int(i==j))for j in range(3)])for i,(m,r)in enumerate(zip(mids,rads))];f=parts(*args);center=parts(*[Jet(ar(m),[arb(int(i==j))for j in range(3)])for i,m in enumerate(mids)])
 if center.v>0:raise RuntimeError(('COUNTEREXAMPLE',list(map(str,mids)),str(center.v)))
 first=center.v+sum((abs(f.g[i])*ar(rads[i])for i in range(3)),arb(0));second=center.v+sum((abs(center.g[i])*ar(rads[i])for i in range(3)),arb(0))+sum((abs(f.h[i][j])*ar(rads[i]*rads[j]/2)for i in range(3)for j in range(3)),arb(0));upper=min(f.v.upper(),first.upper(),second.upper())
 if upper<-ar(F(1,10**7)):return True,0,upper
 scores=[float((abs(center.g[i])*ar(rads[i])+sum((abs(f.h[i][j])*ar(rads[i]*rads[j])for j in range(3)),arb(0))).abs_upper())for i in range(3)];axis=max(range(3),key=lambda i:scores[i])if all(math.isfinite(v)for v in scores)else max(range(3),key=lambda i:rads[i]);return False,axis,upper
trace=(D/(mode+'_trace.bin')).read_bytes();stack=[tuple([F(0),F(1)]*3)];leaves=0;maxupper=-arb(10**20);start=time.time()
for num,code in enumerate(trace):
 assert stack and code in (0,1,2,3)
 box=stack.pop()
 if code:
  axis=code-1;i=2*axis;mid=(box[i]+box[i+1])/2;assert box[i]<mid<box[i+1]
  left=list(box);right=list(box);left[i+1]=mid;right[i]=mid;stack.extend([tuple(left),tuple(right)])
 else:
  ok,axis,upper=check(box);assert ok,(num,box,str(upper));leaves+=1;maxupper=max(maxupper,upper)
 if num%10000==0:print(mode,num,leaves,len(stack),time.time()-start,flush=True)
assert not stack and len(trace)==2*leaves-1
result=dict(status='PASS all accepted leaves independently replayed; exact complete trace coverage',mode=mode,nodes=len(trace),leaves=leaves,precision=ctx.prec,maxupper=str(maxupper),input_sha=hashlib.sha256((D/'frozen.json').read_bytes()).hexdigest(),trace_sha=hashlib.sha256(trace).hexdigest())
(Path(__file__).parent/(mode+'_independent_result.json')).write_text(json.dumps(result,indent=2));print(result,flush=True)
