from flint import arb,arb_poly,fmpq,fmpq_poly,ctx
import random,json
ctx.prec=512; rng=random.Random(271828);count=0
for deg in [0,1,29,58,71]:
 for j in range(20):
  co=[fmpq(rng.randint(-1000000,1000000),rng.randint(1,1000000)) for _ in range(deg+1)]
  mid=fmpq(rng.randint(-1000,1000),1024)
  exact=fmpq_poly(co)(fmpq_poly([mid,1]));interval=arb_poly([arb(v) for v in co])(arb_poly([arb(mid),1]))
  for i in range(deg+1):assert interval[i].contains(arb(exact[i]))
  count+=1
print(json.dumps(dict(status='PASS exact independent rational polynomial composition contained',cases=count,precision=512)))
