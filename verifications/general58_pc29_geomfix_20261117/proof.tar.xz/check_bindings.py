import sys,json,hashlib,math
from pathlib import Path
from fractions import Fraction as F
from flint import arb,ctx
assert __debug__;sys.set_int_max_str_digits(0);ctx.prec=2048
D=Path(__file__).parent; S=D/'scalar';k=json.loads((S/'kernel.json').read_text());n=k['dimension'];d=F(json.loads((S/'annular_certificate.json').read_text())['d'])
assert (S/'kernel.json').read_bytes()==(D/f'geometry/dim{n}/frozen.json').read_bytes()
a=json.loads((S/'annular_certificate.json').read_text());p=json.loads((S/'repaired.json').read_text());assert a['P']==p['P'] and F(a['s'])==F(k['s']);assert a['dimension']==p['dimension']==n
co=list(map(F,k['co']));B=[[[F(v)for v in row]for row in b]for b in k['B']];z=list(map(F,k['z']));s=F(k['s']);assert len(co)==len(B)==30 and co[0]==1 and min(co)>0 and F(k['q'])==sum(co)
for b in B:
 assert len(b)==2 and all(len(row)==2 for row in b) and b[0][1]==b[1][0]
 assert b[0][0]>=0 and b[1][1]>=0 and b[0][0]*b[1][1]>=b[0][1]**2
b=B[0];det=b[0][0]*b[1][1]-b[0][1]**2;assert det>0 and s>(b[1][1]*z[0]**2-2*b[0][1]*z[0]*z[1]+b[0][0]*z[1]**2)/det
c=json.loads((S/'caps/result.json').read_text());edge=d
for r in c['rows']:
 assert F(r['l'])==edge and 0<F(r['r'])-edge<=d
 edge=F(r['r']);assert F(r['height'])>=0
 if F(r['height'])>0:
  assert r['cap_certificate'] is not None
  cap=json.loads((S/'caps'/r['cap_certificate']).read_text());assert r['cap']==cap['cap']
assert n==58 and edge==F(a['cut'])==180 and len(c['rows'])==616 and d==26
obj=F(p['P'][0])+s+F(c['budget']);assert obj>0
result=json.loads((S/'caps/density_result.json').read_text());safe=F(result['safe_upper'])
def ar(x):x=F(x);return arb(x.numerator)/x.denominator
value=ar(obj)*ar(d/4)**(arb(n)/2)/(arb(n)/2+1).gamma();assert value<ar(safe)
if n%2==0:
 exact=(d/4)**(n//2)/math.factorial(n//2)*obj;assert exact==F(result['density_exact']) and exact<safe
 env=exact
else:
 def atan(q,N):return sum((F((-1)**j,(2*j+1)*q**(2*j+1)) for j in range(N)),F(0))
 pi_lo=16*atan(5,300)-4*atan(239,301);assert ar(pi_lo)<arb.pi()
 m=(n+1)//2;const=obj**2*4*math.factorial(m)**2*d**n/math.factorial(2*m)**2
 assert safe**2>const/pi_lo
 assert F(result['squared_density_upper'])==const/F(result['pi_lower'])
 assert ar(F(result['pi_lower']))<arb.pi()
 env=F(result['density_rational_upper']);assert value<ar(env)<ar(safe)
assert safe==F(-(-(env*10**15).numerator//(env*10**15).denominator),10**15)
g=D/f'geometry/dim{n}';source=json.loads((g/'main_result.json').read_text());replay=json.loads((D/'main_independent_result.json').read_text());assert replay['nodes']==2*replay['leaves']-1
assert source['status']=='COMPLETE INTERVAL COVERAGE PASS'
assert all(source[key]==replay[key] for key in ['nodes','leaves','input_sha','trace_sha'])
assert a['kernel_sha256']==hashlib.sha256((S/'kernel.json').read_bytes()).hexdigest()
assert replay['input_sha']==hashlib.sha256((S/'kernel.json').read_bytes()).hexdigest() and replay['trace_sha']==hashlib.sha256((g/'main_trace.bin').read_bytes()).hexdigest()
print(json.dumps(dict(status='PASS exact PSD, bindings, annuli coverage, independently normalized safe upper',dimension=n,safe_upper=str(safe),value=str(value),kernel_sha=replay['input_sha'],nodes=replay['nodes'],leaves=replay['leaves']),indent=2))
