# 53D compact cyclic matrix upper-bound candidate: repaired geometry

Candidate scalar upper: 6.8841195e-08. PRODUCER COMPLETE: complete3D cyclic interval proof passes. Independent audit remains pending; do not publish before it passes.

This is a new frozen candidate, not the rejected ../general53_pc29_repair_20261117 package. All12edges are proved by interval arithmetic. Entire angular[-1,1/2] rectangle-corner signs, exact PSD/Schur origin, Fourier positive factors/involution, fullspatial tail, annular coverage and cap normalization pass.

The degree29 normalized Gegenbauer kernel has30 PSD2x2 blocks and profiles h,h² with h=((19/13−t)/(6/13))_+^12. The degree71 radial Fourier polynomial is repaired into positive factors. No lattice, mod2 or antipodal premise is used.

Requirements: Python,numpy,sympy,python-flint,scipy; assertions enabled.
python geometry/verify_caps.py 53
python geometry/verify_edges.py 53
python geometry/gate.py 53
python scalar/verify_fourier_tail.py
python scalar/certify_annuli.py
python scalar/build_caps.py 53
python scalar/verify_caps.py 53

See geometry/THEOREM.md for the counting framework; its discovery-only concluding note is historical and does not replace the explicit status here. Discovery provenance is preserved as producer_candidate.json. No public repository edit by this producer.
