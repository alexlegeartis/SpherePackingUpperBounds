PRODUCER COMPLETE: unrestricted53D upper6.8841195e-08. Full3D cyclic coverage132889nodes/66445leaves. Independent audit pending.
