# Verified intermediate-power rank-three extension in dimension 51

The producer's complete cyclic coverage and the independent audit have both passed. The unrestricted sphere-packing density bound is 1.38612634e-7. See AUDIT.md, AUDIT_COMPLETE.json and the complete replay receipts for scope and reproducibility. No lattice, integrality, mod-2 or antipodal premise is used.

## Profiles and support-crossing geometry

For squared distance t normalized so the minimum is 1, put beta(t)=max((R-t)/(R-1),0), R=19/13. Define h(t)=beta(t)^12 and g(t)=beta(t)^6. The three radial features are

H(t)=(beta(t)^12,beta(t)^18,beta(t)^24)=h(t)(1,g(t),g(t)^2).

The vector (1,u,u^2), for 0<=u<=1, is the convex combination

(1-u)^2(1,0,0)+2u(1-u)(1,1/2,0)+u^2(1,1,1).

Thus the six distinct symmetric tensor-Bernstein control contractions of the angular 3x3 matrix suffice to certify nonpositivity of the full biquadratic expression for every u,v in [0,1]. Each of these six polynomial controls is verified on the entire angular interval [-1,1/2], including negative cosines. They are not merely corner evaluations of a bilinear polynomial in u,v.

In the ordered full-support cube, a=1+(6/13)x, b=a+(6/13)(1-x)y, c=b+(6/13)(1-x)(1-y)z. After dividing the interior cyclic expression by h(a)h(b), its continuous extension uses sixth-power arguments g(a),g(b),g(c), but twelfth-power cyclic prefactors (1-z)^12 and ((1-y)(1-z))^12. The complete closed cube is covered by the interval proof, so zero-profile boundaries are not omitted.

## Scalar correction and degrees

With q=sum c_k and W=sum c_k B_k/q, the compact scalar correction is 2 z^T H/q + H^T W H/q. Here z is the origin coupling vector, distinct from the cube coordinate named z above. In the Gaussian radial coordinate X=pi|v|^2, substitute t=X/d, where d=22. On active support, beta(X/d) is affine in X. The correction has degree 48 in X: its linear profile terms have degrees 12,18,24 and its quadratic terms have degrees up to 48. Equivalently, in g=beta^6, it has linear terms g^2,g^3,g^4 and quadratic terms through g^8.

Separately, the radial Gaussian function is e^(-X)P(X), and its Gaussian Fourier polynomial is Q; both P and Q have degree 71. The full residual, the Gaussian function plus the compact correction, is not a polynomial. All 633 radial annuli from d=22 through X=180 are certified, along with the complete infinite Gaussian tail.

Each harmonic matrix is 3x3 PSD and the origin Schur block is 4x4 PSD. Exact principal-minor and Schur-complement checks, all six angular controls, all 12 cube edges, full cyclic coverage, Fourier positivity, radial/cap bounds, and independently reconstructed odd-dimensional normalization and safe rounding passed. The independent cyclic replay sums all nine matrix entries and uses rigorous outward-rounded Arb arithmetic.
