from pathlib import Path
import sys,subprocess,json,hashlib
assert __debug__
D=Path(__file__).resolve().parent
jobs=[['replay_geometry.py','51'],['geometry/verify_caps.py','51'],['geometry/verify_edges.py','51'],['scalar/verify_fourier_tail.py'],['scalar/certify_annuli.py'],['scalar/verify_caps.py','51'],['check_bindings.py']]
with (D/'fast_shift_validation.log').open('w')as f:subprocess.run([sys.executable,str(D/'validate_fast_shift.py')],cwd=D,stdout=f,stderr=subprocess.STDOUT,check=True)
for i,cmd in enumerate(jobs):
 print('RUN',i,cmd,flush=True)
 with (D/f'audit_{i}.log').open('w')as f:
  r=subprocess.run([sys.executable,*cmd],cwd=D,stdout=f,stderr=subprocess.STDOUT)
 if r.returncode:
  (D/'AUDIT_FAILED.json').write_text(json.dumps({'stage':i,'command':cmd,'returncode':r.returncode},indent=2));raise RuntimeError((i,cmd,r.returncode))
hashes=json.load(open(D/'AUDIT_INPUT_HASHES.json'))
for p,h in hashes.items():assert hashlib.sha256((D/p).read_bytes()).hexdigest()==h,p
(D/'AUDIT_COMPLETE.json').write_text(json.dumps({'status':'PASS all sequential independent replays','dimension':51,'profiles':[8,12,16],'hashes':hashes},indent=2)+'\n')
print('ALL SEVEN INDEPENDENT STAGES PASS',flush=True)
