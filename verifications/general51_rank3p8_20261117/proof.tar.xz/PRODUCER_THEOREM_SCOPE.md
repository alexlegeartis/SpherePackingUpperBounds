# Experimental compact rank-three kernel, powers8/12/16

NOT unconditional until complete3D cyclic coverage and independent audit pass.

Let a0=max((R-a)/(R-1),0), R=19/13, and h=a0^4. Features H=(h²,h³,h⁴)=(a0^8,a0^12,a0^16). Factoring h² leaves(1,h,h²), so the same six Bernstein corner polynomials suffice for support-crossing signs. In the ordered full-support cube, cyclic ratios have exponent8 and profile variables exponent4. The scalar compact correction is2zᵀH/q+HᵀWH/q, W=sum c_kB_k/q, of degree32 in a0. The origin block is4×4, with no lattice assumptions.

Exact PSD, full angular signs,12edges and scalar certificates pass. Conditional safe density1.37781396e-7. Full3D and independent audit remain pending. The initial unused ha/hb/hc definitions in the evaluator do not enter the returned expression; the returned cyclic expression uses ua/ub/uc with exponent4 and prefactors with exponent8.
