# Counting theorem for the three-feature compact kernel

This note supplies the dimension-independent counting argument used with the exact inputs. Standard Gegenbauer positive definiteness, Poisson summation for Schwartz functions, and periodic approximation of sphere packings are mathematical inputs, not machine-formalized theorems here.

Let n=51, R=19/13, beta(t)=max((R-t)/(R-1),0), and H(t)=(beta(t)^8,beta(t)^12,beta(t)^16). Angular P_k are normalized n-dimensional Gegenbauer polynomials with P_k(1)=1. With c_k>0, c_0=1, q=sum c_k, define for nonzero displacement vectors

K(x,y)=q^(-2) sum_k c_k P_k(cos(x,y)) H(|x|²)^T B_k H(|y|²),
K(0,x)=q^(-1) z^T H(|x|²), K(0,0)=s.

Each B_k is a 3-by-3 PSD matrix, and [[s,z^T],[z,B_0]] is PSD. The Gegenbauer addition theorem gives a feature-map proof that the full origin-extended K is PSD. No antipodal or lattice assumption is needed. Put W=sum c_k B_k/q. Then K(x,x)=H^T W H/q.

For three distinct packing points, require the sum of the three vertex-centered K terms to be nonpositive. For squared triangle sides in the support, this is the cyclic function certified on the entire ordered cube. If two sides exceed R all terms vanish. If only the longest side exceeds R, the surviving angle cosine lies in [-1,1/2]; the six tensor-Bernstein controls in THEOREM_SCOPE.md prove its sign. The normalized cube formulation extends continuously to zero-profile boundaries.

For any packing center, apply kernel PSD to that center (the origin) and all neighboring points within support. Summing over centers of a periodic packing, each triple contributes its cyclic sum, with the ordered-pair multiplicity. The nonpositive triple contribution implies

average_per_center sum_{other points} (2 K(0,x)+K(x,x)) >= -s.

Now take f(v)=exp(-X)P(X), X=pi|v|², with nonnegative Fourier transform and Fourier(f)(0)=1. Minimum separation corresponds to X=d=22; use H(X/d) in the compact correction. The residual is

f(v)+(2 z^T H+H^T W H)/q.

Its positive part is bounded on each certified radial annulus by g_i>=0. A universal spherical-code bound C_i limits the neighbors in that annulus; every such cap is separately certified. All residual regions and the infinite tail are covered. Thus the per-center residual sum is at most E=sum_i C_i g_i, and the preceding kernel inequality yields average sum_{other points} f(v)<=s+E.

Poisson summation and Fourier positivity bound the number density by P(0)+s+E. Multiplication by the volume of a ball of radius sqrt(d/pi)/2 gives

packing density <= (d/4)^(n/2)/Gamma(n/2+1) * (P(0)+s+E).

The safe decimal is strictly greater than this proved expression. The usual periodic approximation argument extends the bound to unrestricted packings. Only f is subject to Schwartz/Poisson assumptions: the compact kernel enters finite local sums, so no Fourier-domain truncation of f is being made. THEOREM_SCOPE.md explains the intermediate powers, and AUDIT.md identifies the complete interval, algebraic and normalization checks.
