# Verified rank-three kernel with radial powers 8,12,16

For squared distance t normalized to minimum 1, let beta(t)=max((19/13-t)/(6/13),0), h=beta^8 and g=beta^4. The physical profiles are H=(beta^8,beta^12,beta^16)=h(1,g,g²). After factoring h(a)h(b), the ordered compact cube uses fourth-power feature variables and eighth-power cyclic prefactors. Its continuous extension covers zero-profile boundaries.

For u in [0,1], (1,u,u²)=(1-u)²(1,0,0)+2u(1-u)(1,1/2,0)+u²(1,1,1). Six symmetric tensor-Bernstein controls therefore certify the entire feature square for every angular cosine in [-1,1/2]. These are not merely sampled corners of the physical curved feature locus.

All30 harmonic matrices are 3-by-3 PSD; the origin Schur block is 4-by-4. The compact scalar correction is 2zᵀH/q+HᵀWH/q, W=sum c_kB_k/q. Its polynomial degree is 32 in the active-support squared-radius coordinate, while the Gaussian polynomial and its Fourier polynomial have degree 71. The full residual, which includes a Gaussian, is not a polynomial.

Full independent proof passed for the closed three-dimensional geometry domain, all angular controls/edges, exact PSD, Fourier positivity and infinite tail, 633 radial annuli from contact 22 through cutoff 180, exact code-cap budgets, and independently derived odd-dimensional normalization. The safe strict upper is 1.37781396e-7. See COUNTING_THEOREM.md for the counting argument, AUDIT.md for independence scope, and original producer notes under PRODUCER_* for history. No lattice, parity, integrality or antipodal assumption is made.
