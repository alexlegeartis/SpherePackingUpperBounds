PRODUCER COMPLETE: unrestricted51D conditional upper1.37781396e-07. Full cyclic91139nodes/45570leaves. Independent audit pending. No publication until it passes.
