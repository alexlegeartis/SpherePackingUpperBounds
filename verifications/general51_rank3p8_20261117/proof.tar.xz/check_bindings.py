import sys,json,hashlib,math
from pathlib import Path
from fractions import Fraction as F
from flint import arb,ctx
assert __debug__;sys.set_int_max_str_digits(0);ctx.prec=2048
D=Path(__file__).parent; S=D/'scalar';k=json.loads((S/'kernel.json').read_text());n=k['dimension'];d=F(json.loads((S/'annular_certificate.json').read_text())['d'])
assert (S/'kernel.json').read_bytes()==(D/f'geometry/dim{n}/frozen.json').read_bytes()
a=json.loads((S/'annular_certificate.json').read_text());p=json.loads((S/'repaired.json').read_text());assert a['P']==p['P'] and F(a['s'])==F(k['s']);assert a['dimension']==p['dimension']==n
co=list(map(F,k['co']));B=[[[F(v)for v in row]for row in b]for b in k['B']];z=list(map(F,k['z']));s=F(k['s']);assert len(co)==len(B)==30 and co[0]==1 and min(co)>0 and F(k['q'])==sum(co)
import sympy as sym,itertools
for block in B:
 M=sym.Matrix(block);assert M==M.T and M.shape==(3,3)
 for size in (1,2,3):
  for ix in itertools.combinations(range(3),size):assert M.extract(ix,ix).det()>=0
M=sym.Matrix(B[0]);Z=sym.Matrix(z);assert M.det()>0 and s>(Z.T*M.inv()*Z)[0]
assert k['powers']==[8,12,16]
# Independently derive scalar correction from features in the base polynomial.
from flint import fmpq as Q,fmpq_poly as Poly
base=Poly([Q(19,6),-Q(13,6)/Q(str(d))]);H=[base**power for power in k['powers']]
poly=sum((Q(str(2*z[i]/sum(co)))*H[i] for i in range(3)),Poly([0]))
poly+=sum((Q(str(sum(co[j]*B[j][i][l] for j in range(30))/sum(co)**2))*H[i]*H[l] for i in range(3) for l in range(3)),Poly([0]))
assert poly.degree()==32 and list(map(str,poly))==a['kernel_polynomial']
c=json.loads((S/'caps/result.json').read_text());edge=d
for r in c['rows']:
 assert F(r['l'])==edge and 0<F(r['r'])-edge<=d
 edge=F(r['r']);assert F(r['height'])>=0
 if F(r['height'])>0:
  assert r['cap_certificate'] is not None
  cap=json.loads((S/'caps'/r['cap_certificate']).read_text());assert r['cap']==cap['cap']
assert n==51 and d==22 and edge==180 and len(c['rows'])==633
obj=F(p['P'][0])+s+F(c['budget']);assert obj>0
result=json.loads((S/'caps/density_result.json').read_text());safe=F(result['safe_upper'])
def ar(x):x=F(x);return arb(x.numerator)/x.denominator
value=ar(obj)*ar(d/4)**(arb(n)/2)/(arb(n)/2+1).gamma();assert value<ar(safe)
if n%2==0:
 exact=(d/4)**(n//2)/math.factorial(n//2)*obj;assert exact==F(result['density_exact']) and exact<safe
 env=exact
else:
 def atan(q,N):return sum((F((-1)**j,(2*j+1)*q**(2*j+1)) for j in range(N)),F(0))
 pi_lo=16*atan(5,300)-4*atan(239,301);assert ar(pi_lo)<arb.pi()
 m=(n+1)//2;const=obj**2*4*math.factorial(m)**2*d**n/math.factorial(2*m)**2
 assert safe**2>const/pi_lo
 assert F(result['squared_density_upper'])==const/F(result['pi_lower'])
 assert ar(F(result['pi_lower']))<arb.pi()
 env=F(result['density_rational_upper']);assert value<ar(env)<ar(safe)
assert safe==F(-(-(env*10**15).numerator//(env*10**15).denominator),10**15)
g=D/f'geometry/dim{n}';source=json.loads((g/'main_result.json').read_text());replay=json.loads((D/'main_independent_result.json').read_text());assert replay['nodes']==2*replay['leaves']-1
assert source['status']=='COMPLETE INTERVAL COVERAGE PASS'
assert all(source[key]==replay[key] for key in ['nodes','leaves','input_sha','trace_sha'])
assert a['kernel_sha256']==hashlib.sha256((S/'kernel.json').read_bytes()).hexdigest()
assert replay['input_sha']==hashlib.sha256((S/'kernel.json').read_bytes()).hexdigest() and replay['trace_sha']==hashlib.sha256((g/'main_trace.bin').read_bytes()).hexdigest()
print(json.dumps(dict(status='PASS exact PSD, bindings, annuli coverage, independently normalized safe upper',dimension=n,safe_upper=str(safe),value=str(value),kernel_sha=replay['input_sha'],nodes=replay['nodes'],leaves=replay['leaves']),indent=2))
# Exact Bernstein feature identity underlying the six support-crossing tests.
u=sym.symbols('u');T=sym.Matrix([[1,0,0],[1,sym.Rational(1,2),0],[1,1,1]])
w=sym.Matrix([[(1-u)**2,2*u*(1-u),u**2]])
assert all(sym.expand(v)==0 for v in (w*T-sym.Matrix([[1,u,u*u]])))
# All six tested polynomials must equal the exact control contractions.
G=[sym.Integer(1),u]
for j in range(2,30):G.append(sym.expand(((2*j+n-4)*u*G[-1]-(j-1)*G[-2])/(j+n-3)))
Qmat=sum((sym.Matrix(B[j])*sym.Rational(co[j].numerator,co[j].denominator)*G[j] for j in range(30)),sym.zeros(3))
controls=json.loads((D/'geometry/dim51/caps_result.json').read_text())['corners'];idx=0
for i in range(3):
 for j in range(i,3):
  expected=sym.Poly((T.row(i)*Qmat*T.row(j).T)[0],u)
  actual=sum(sym.Rational(v)*u**k for k,v in enumerate(controls[idx]['polynomial']))
  assert sym.expand(actual-expected.as_expr())==0;idx+=1
print('PASS independently derived six Bernstein control polynomials and profile identity')
