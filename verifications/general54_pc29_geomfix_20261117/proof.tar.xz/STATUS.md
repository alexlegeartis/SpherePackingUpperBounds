PRODUCER COMPLETE: unrestricted54D upper4.8695034e-08. Full3D cyclic coverage95299nodes/47650leaves. Independent audit pending.
